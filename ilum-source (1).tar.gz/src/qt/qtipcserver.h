#ifndef QTIPCSERVER_H
#define QTIPCSERVER_H

// Define ILUM-Qt message queue name
#define BITCOINURI_QUEUE_NAME "ILUMURI"

void ipcScanRelay(int argc, char *argv[]);
void ipcInit(int argc, char *argv[]);

#endif // QTIPCSERVER_H
